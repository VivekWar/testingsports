import { useEffect } from 'react';
import './MatchModal.css';

const MatchModal = ({ match, isOpen, onClose }) => {
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') onClose();
    };

    if (isOpen) {
      document.addEventListener('keydown', handleEscape);
      document.body.style.overflow = 'hidden';
    }

    return () => {
      document.removeEventListener('keydown', handleEscape);
      document.body.style.overflow = 'unset';
    };
  }, [isOpen, onClose]);

  if (!isOpen || !match) return null;

  const getStatusText = (status, format, currentOver, totalOvers, day, session) => {
    switch (status) {
      case 'live':
        if (format === 'Test') {
          return `Day ${day}, ${session}`;
        }
        return `${currentOver}/${totalOvers} overs`;
      case 'finished':
        return 'Match Finished';
      case 'upcoming':
        return `Starts at ${match.time}`;
      default:
        return '';
    }
  };

  // FIXED: Proper Test cricket score handling
  const getCurrentScore = (match) => {
    if (!match?.score) {
      return { home: "0/0", away: "Yet to bat" };
    }

    if (match.format === 'Test') {
      // For Test matches, show current innings based on currentInnings
      const currentInningsNum = match.currentInnings || 1;
      
      // Get team names for matching
      const homeTeamName = match.homeTeam?.shortName?.toLowerCase() || 'home';
      const awayTeamName = match.awayTeam?.shortName?.toLowerCase() || 'away';
      
      let homeScore = "0/0";
      let awayScore = "Yet to bat";
      
      // Determine which innings are currently being played
      if (currentInningsNum === 1) {
        // First team batting (first innings)
        const firstInnings = match.score.firstInnings || {};
        const battingTeamScore = firstInnings[homeTeamName] || firstInnings.home || {};
        if (battingTeamScore.runs >= 0) {
          homeScore = `${battingTeamScore.runs || 0}/${battingTeamScore.wickets || 0}`;
        }
        awayScore = "Yet to bat";
      } 
      else if (currentInningsNum === 2) {
        // Second team batting (second innings)
        const firstInnings = match.score.firstInnings || {};
        const secondInnings = match.score.secondInnings || {};
        
        const homeFirstScore = firstInnings[homeTeamName] || firstInnings.home || {};
        const awaySecondScore = secondInnings[awayTeamName] || secondInnings.away || {};
        
        if (homeFirstScore.runs >= 0) {
          homeScore = `${homeFirstScore.runs || 0}/${homeFirstScore.wickets || 0}`;
        }
        if (awaySecondScore.runs >= 0) {
          awayScore = `${awaySecondScore.runs || 0}/${awaySecondScore.wickets || 0}`;
        }
      }
      else if (currentInningsNum === 3) {
        // First team batting again (third innings)
        const firstInnings = match.score.firstInnings || {};
        const secondInnings = match.score.secondInnings || {};
        const thirdInnings = match.score.thirdInnings || {};
        
        const homeFirstScore = firstInnings[homeTeamName] || firstInnings.home || {};
        const awaySecondScore = secondInnings[awayTeamName] || secondInnings.away || {};
        const homeThirdScore = thirdInnings[homeTeamName] || thirdInnings.home || {};
        
        // Show both innings for home team if third innings exists
        if (homeThirdScore.runs >= 0) {
          const firstInns = homeFirstScore.runs >= 0 ? `${homeFirstScore.runs}/${homeFirstScore.wickets}` : "0/0";
          const thirdInns = `${homeThirdScore.runs}/${homeThirdScore.wickets}`;
          homeScore = `${firstInns} & ${thirdInns}`;
        } else if (homeFirstScore.runs >= 0) {
          homeScore = `${homeFirstScore.runs}/${homeFirstScore.wickets}`;
        }
        
        if (awaySecondScore.runs >= 0) {
          awayScore = `${awaySecondScore.runs}/${awaySecondScore.wickets}`;
        }
      }
      else if (currentInningsNum === 4) {
        // Second team batting again (fourth innings)
        const firstInnings = match.score.firstInnings || {};
        const secondInnings = match.score.secondInnings || {};
        const thirdInnings = match.score.thirdInnings || {};
        const fourthInnings = match.score.fourthInnings || {};
        
        const homeFirstScore = firstInnings[homeTeamName] || firstInnings.home || {};
        const awaySecondScore = secondInnings[awayTeamName] || secondInnings.away || {};
        const homeThirdScore = thirdInnings[homeTeamName] || thirdInnings.home || {};
        const awayFourthScore = fourthInnings[awayTeamName] || fourthInnings.away || {};
        
        // Show both innings for both teams
        if (homeThirdScore.runs >= 0 && homeFirstScore.runs >= 0) {
          homeScore = `${homeFirstScore.runs}/${homeFirstScore.wickets} & ${homeThirdScore.runs}/${homeThirdScore.wickets}`;
        } else if (homeFirstScore.runs >= 0) {
          homeScore = `${homeFirstScore.runs}/${homeFirstScore.wickets}`;
        }
        
        if (awayFourthScore.runs >= 0 && awaySecondScore.runs >= 0) {
          awayScore = `${awaySecondScore.runs}/${awaySecondScore.wickets} & ${awayFourthScore.runs}/${awayFourthScore.wickets}`;
        } else if (awaySecondScore.runs >= 0) {
          awayScore = `${awaySecondScore.runs}/${awaySecondScore.wickets}`;
        }
      }
      
      return { home: homeScore, away: awayScore };
    } 
    else {
      // Limited overs cricket (ODI/T20)
      if (match.currentInnings === 2 && match.score.innings2) {
        if (match.score.innings2?.home?.runs > 0) {
          return {
            home: `${match.score.innings2.home.runs}/${match.score.innings2.home.wickets}`,
            away: match.score.innings1?.away ? 
              `${match.score.innings1.away.runs}/${match.score.innings1.away.wickets}` : "0/0"
          };
        } else if (match.score.innings2?.away?.runs > 0) {
          return {
            home: match.score.innings1?.home ? 
              `${match.score.innings1.home.runs}/${match.score.innings1.home.wickets}` : "0/0",
            away: `${match.score.innings2.away.runs}/${match.score.innings2.away.wickets}`
          };
        }
      }
      
      const homeScore = match.score.innings1?.home;
      const awayScore = match.score.innings1?.away;
      
      return {
        home: homeScore ? `${homeScore.runs}/${homeScore.wickets}` : "0/0",
        away: awayScore && awayScore.runs > 0 ? 
          `${awayScore.runs}/${awayScore.wickets}` : "Yet to bat"
      };
    }
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
      year: 'numeric'
    });
  };

  const currentScore = getCurrentScore(match);

  // Get current innings display text for Test matches
  const getCurrentInningsText = () => {
    if (match.format !== 'Test' || !match.currentInnings) return '';
    
    const inningsNames = {
      1: "1st Innings",
      2: "2nd Innings", 
      3: "3rd Innings",
      4: "4th Innings"
    };
    
    return inningsNames[match.currentInnings] || '';
  };

  return (
    <div className="clean-modal-overlay" onClick={onClose}>
      <div className="clean-modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="clean-modal-close" onClick={onClose}>×</button>
        
        {/* Streamlined Header */}
        <div className="clean-modal-header">
          <div className="clean-status-row">
            <div className="clean-status">
              <span className={`clean-status-dot ${match.status}`}></span>
              <span className="clean-status-text">
                {match.status === 'live' ? 'LIVE' : 
                 match.status === 'finished' ? 'FINISHED' : 'UPCOMING'}
              </span>
            </div>
            <div className="clean-competition">
              <span className="clean-comp-name">{match.competition}</span>
              <span className="clean-stage">{match.stage}</span>
            </div>
          </div>
          
          <div className="clean-match-info">
            <div className="clean-date">{formatDate(match.date)}</div>
            <div className="clean-meta">
              <span className="clean-format">{match.format}</span>
              <span className="clean-venue">{match.venue}</span>
              <span className="clean-time">
                {getStatusText(match.status, match.format, match.currentOver, match.totalOvers, match.day, match.session)}
              </span>
              {match.format === 'Test' && match.currentInnings && match.status === 'live' && (
                <span className="clean-current-innings">{getCurrentInningsText()}</span>
              )}
            </div>
          </div>
        </div>

        {/* Clean Teams Section */}
        <div className="clean-teams">
          <div className="clean-team">
            <div className="clean-team-name">{match.homeTeam?.name || 'TBA'}</div>
            <div className="clean-team-score">{currentScore.home}</div>
          </div>
          
          <div className="clean-vs">vs</div>
          
          <div className="clean-team">
            <div className="clean-team-name">{match.awayTeam?.name || 'TBA'}</div>
            <div className="clean-team-score">{currentScore.away}</div>
          </div>
        </div>

        {/* Test Match Additional Info */}
        {match.format === 'Test' && match.status === 'live' && (
          <div className="clean-test-info">
            {match.currentLead && (
              <div className="clean-lead-display">
                Current Lead: {Math.abs(match.currentLead)} runs
              </div>
            )}
            {match.firstInningsLead && (
              <div className="clean-first-innings-lead">
                First Innings Lead: {Math.abs(match.firstInningsLead)} runs
              </div>
            )}
          </div>
        )}

        {/* Conditional Content Based on Status */}
        {match.status === 'live' && (
          <div className="clean-live-info">
            {match.currentBatsmen && (
              <div className="clean-batsmen">
                <div className="clean-section-title">Current Partnership</div>
                <div className="clean-batsmen-row">
                  <div className="clean-batsman">
                    <span className="clean-batsman-name">
                      {match.currentBatsmen.striker?.name || 'Unknown'}*
                    </span>
                    <span className="clean-batsman-score">
                      {match.currentBatsmen.striker?.runs || 0}({match.currentBatsmen.striker?.balls || 0})
                    </span>
                  </div>
                  <div className="clean-batsman">
                    <span className="clean-batsman-name">
                      {match.currentBatsmen.nonStriker?.name || 'Unknown'}
                    </span>
                    <span className="clean-batsman-score">
                      {match.currentBatsmen.nonStriker?.runs || 0}({match.currentBatsmen.nonStriker?.balls || 0})
                    </span>
                  </div>
                </div>
              </div>
            )}
            
            {match.runRate && match.format !== 'Test' && (
              <div className="clean-rates">
                {match.runRate.current && (
                  <div className="clean-rate-item">
                    <span>Run Rate:</span>
                    <span>{match.runRate.current}</span>
                  </div>
                )}
                {match.runRate.required && (
                  <div className="clean-rate-item">
                    <span>Required:</span>
                    <span>{match.runRate.required}</span>
                  </div>
                )}
                {match.targetRuns && (
                  <div className="clean-rate-item">
                    <span>Target:</span>
                    <span>{match.targetRuns}</span>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {match.status === 'upcoming' && (
          <div className="clean-upcoming-info">
            <div className="clean-upcoming-text">
              Match starts {new Date(`${match.date}T${match.time}`).toLocaleString()}
            </div>
            {match.totalOvers && (
              <div className="clean-upcoming-detail">
                {match.totalOvers} overs per side
              </div>
            )}
          </div>
        )}

        {match.status === 'finished' && (
          <div className="clean-finished-info">
            {match.result && (
              <div className="clean-result">{match.result}</div>
            )}
            {match.playerOfTheMatch && (
              <div className="clean-potm">
                Player of the Match: <strong>{match.playerOfTheMatch}</strong>
              </div>
            )}
          </div>
        )}

        {/* Simple Footer */}
        {match.toss && (
          <div className="clean-footer">
            Toss: {match.toss.winner} won & chose to {match.toss.decision}
          </div>
        )}
      </div>
    </div>
  );
};

export default MatchModal;
