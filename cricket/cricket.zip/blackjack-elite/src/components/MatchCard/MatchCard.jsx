import './MatchCard.css';

const MatchCard = ({ match, onCardClick }) => {
  const getStatusText = (status, format, currentOver, totalOvers, day, session) => {
    switch (status) {
      case 'live':
        if (format === 'Test') {
          return `Day ${day}, ${session}`;
        }
        return `${currentOver}/${totalOvers} overs`;
      case 'finished':
        return 'Result';
      case 'upcoming':
        return match.time;
      default:
        return '';
    }
  };

  const getStatusClass = (status) => {
    return status;
  };

  // Safe property access with null checks
  const getCurrentScore = (match) => {
    // Safety checks - return default if data is missing
    if (!match?.score) {
      return {
        home: "0/0",
        away: "YTB"
      };
    }

    // Check if second innings is active and exists
    if (match.currentInnings === 2 && match.score.innings2) {
      if (match.score.innings2?.home?.runs > 0) {
        return {
          home: `${match.score.innings2.home.runs}/${match.score.innings2.home.wickets}`,
          away: match.score.innings1?.away ? 
            `${match.score.innings1.away.runs}/${match.score.innings1.away.wickets}` : "0/0"
        };
      } else if (match.score.innings2?.away?.runs > 0) {
        return {
          home: match.score.innings1?.home ? 
            `${match.score.innings1.home.runs}/${match.score.innings1.home.wickets}` : "0/0",
          away: `${match.score.innings2.away.runs}/${match.score.innings2.away.wickets}`
        };
      }
    }
    
    // Default to first innings with safe access
    const homeScore = match.score.innings1?.home;
    const awayScore = match.score.innings1?.away;
    
    return {
      home: homeScore ? `${homeScore.runs}/${homeScore.wickets}` : "YTB",
      away: awayScore && awayScore.runs > 0 ? 
        `${awayScore.runs}/${awayScore.wickets}` : "YTB"
    };
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric'
    });
  };

  const currentScore = getCurrentScore(match);

  const handleCardClick = () => {
    if (onCardClick) {
      onCardClick(match);
    }
  };

  return (
    <div 
      className="match-card cricket-match-card" 
      data-match-id={match.id}
      onClick={handleCardClick}
    >
      {/* Header */}
      <div className="card-header">
        <div className={`match-status ${getStatusClass(match.status)}`}>
          <span className={`status-dot ${match.status}`}></span>
          <span className="status-text">
            {match.status === 'live' ? 'LIVE' : 
             match.status === 'finished' ? 'FINISHED' : 'UPCOMING'}
          </span>
        </div>
        <div className="competition-badge">
          {match.competition}
        </div>
      </div>

      {/* Teams and Score Section */}
      <div className="teams-score-section">
        <div className="teams-container">
          <div className="team-info home-team">
            <span className="team-name">{match.homeTeam?.shortName || 'TBA'}</span>
          </div>
          
          <div className="match-score-display">
            <div className="score-line">
              {currentScore.home} - {currentScore.away}
            </div>
            <div className="match-details">
              <span className="over-info">
                {getStatusText(match.status, match.format, match.currentOver, match.totalOvers, match.day, match.session)}
              </span>
              {match.format && (
                <span className="format-tag">{match.format}</span>
              )}
            </div>
          </div>
          
          <div className="team-info away-team">
            <span className="team-name">{match.awayTeam?.shortName || 'TBA'}</span>
          </div>
        </div>
      </div>

      {/* REMOVED: Current Batsmen Section - This entire section is now removed */}

      {/* Footer */}
      <div className="card-footer">
        <div className="venue-display">
          {match.venue || 'TBA'}
        </div>
        <div className="match-extras">
          {match.status === 'upcoming' && (
            <div className="match-date-display">
              {formatDate(match.date)}
            </div>
          )}
          {match.runRate?.current && (
            <div className="rate-display">
              RR: {match.runRate.current}
              {match.runRate.required && ` | Req: ${match.runRate.required}`}
            </div>
          )}
          {match.targetRuns && (
            <div className="target-display">
              Target: {match.targetRuns}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MatchCard;
