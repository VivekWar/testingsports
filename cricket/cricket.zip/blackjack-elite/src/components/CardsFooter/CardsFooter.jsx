import './CardsFooter.css'; // Adjust path as needed

const CardsFooter = () => (
  <footer className="footer-bar">
    <div className="footer-content">
      <div className="footer-logo-section">
        <img src="" alt="UDGOSH Logo" className="footer-logo-img" />
        <span className="footer-brand-name">UDGOSH</span>
      </div>
      <div className="footer-mid">
        create. compete. celebrate.
        <div className="footer-copyright">
          © {new Date().getFullYear()} UDGOSH Sports Fest – All rights reserved
        </div>
      </div>
      <nav className="footer-nav">
        <a href="#">Home</a>
        <span>|</span>
        <a href="#">Live</a>
        <span>|</span>
        <a href="#">Schedule</a>
        <span>|</span>
        <a href="#">Teams</a>
        <span>|</span>
        <a href="#">Contact</a>
      </nav>
    </div>
  </footer>
);

export default CardsFooter;
