export const cricketMatchData = [
  // LIVE MATCHES (7)
  {
    id: 1,
    date: "2024-08-25",
    time: "19:30",
    status: "live",
    format: "T20",
    currentOver: "12.4",
    totalOvers: 20,
    competition: "IPL",
    venue: "Wankhede Stadium",
    stage: "League Stage",
    currentInnings: 1,
    homeTeam: { name: "Mumbai Indians", code: "MI", shortName: "Mumbai" },
    awayTeam: { name: "Chennai Super Kings", code: "CSK", shortName: "Chennai" },
    toss: { winner: "Mumbai", decision: "bat" },
    score: {
      innings1: { 
        home: { runs: 89, wickets: 3, overs: 12.4 },
        away: { runs: 0, wickets: 0, overs: 0 }
      }
    },
    currentBatsmen: {
      striker: { name: "R. Sharma", runs: 45, balls: 32 },
      nonStriker: { name: "I. Kishan", runs: 23, balls: 18 }
    },
    runRate: { current: 7.12, required: null }
  },
  {
    id: 2,
    date: "2024-08-25",
    time: "15:30",
    status: "live",
    format: "T20",
    currentOver: "8.2",
    totalOvers: 20,
    competition: "BBL",
    venue: "MCG",
    stage: "Final",
    currentInnings: 1,
    homeTeam: { name: "Melbourne Stars", code: "STA", shortName: "Stars" },
    awayTeam: { name: "Sydney Sixers", code: "SIX", shortName: "Sixers" },
    toss: { winner: "Stars", decision: "bat" },
    score: {
      innings1: { home: { runs: 63, wickets: 2, overs: 8.2 }, away: { runs: 0, wickets: 0, overs: 0 } }
    },
    currentBatsmen: {
      striker: { name: "G. Maxwell", runs: 28, balls: 19 },
      nonStriker: { name: "M. Stoinis", runs: 15, balls: 12 }
    },
    runRate: { current: 7.59, required: null }
  },
  {
    id: 3,
    date: "2024-08-25",
    time: "14:00",
    status: "live",
    format: "ODI",
    currentOver: "32.4",
    totalOvers: 50,
    competition: "World Cup",
    venue: "Lord's",
    stage: "Semi Final",
    currentInnings: 2,
    homeTeam: { name: "England", code: "ENG", shortName: "England" },
    awayTeam: { name: "Australia", code: "AUS", shortName: "Australia" },
    toss: { winner: "England", decision: "bat" },
    score: {
      innings1: { home: { runs: 287, wickets: 10, overs: 49.3 }, away: { runs: 0, wickets: 0, overs: 0 } },
      innings2: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 168, wickets: 4, overs: 32.4 } }
    },
    targetRuns: 288,
    currentBatsmen: {
      striker: { name: "S. Smith", runs: 67, balls: 89 },
      nonStriker: { name: "M. Labuschagne", runs: 43, balls: 52 }
    },
    runRate: { current: 5.18, required: 6.94 }
  },
  {
    id: 4,
    date: "2024-08-25",
    time: "10:30",
    status: "live",
    format: "Test",
    day: 3,
    session: "Post Lunch",
    competition: "Border-Gavaskar Trophy",
    venue: "Adelaide Oval",
    stage: "2nd Test",
    currentInnings: 3, // Australia's 2nd innings
    homeTeam: { name: "Australia", code: "AUS", shortName: "Australia" },
    awayTeam: { name: "India", code: "IND", shortName: "India" },
    toss: { winner: "Australia", decision: "bat" },
    score: {
      // Australia 1st innings (won toss, batted first)
      firstInnings: { australia: { runs: 456, wickets: 10, overs: 142.1 }, india: { runs: 0, wickets: 0, overs: 0 } },
      // India 1st innings  
      secondInnings: { australia: { runs: 0, wickets: 0, overs: 0 }, india: { runs: 398, wickets: 10, overs: 128.4 } },
      // Australia 2nd innings (currently batting)
      thirdInnings: { australia: { runs: 198, wickets: 6, overs: 67.2 }, india: { runs: 0, wickets: 0, overs: 0 } },
      // India 2nd innings (not yet)
      fourthInnings: { australia: { runs: 0, wickets: 0, overs: 0 }, india: { runs: 0, wickets: 0, overs: 0 } }
    },
    firstInningsLead: 58, // Australia led by 58 after first innings
    currentLead: 256,
    currentBatsmen: {
      striker: { name: "T. Head", runs: 78, balls: 95 },
      nonStriker: { name: "A. Carey", runs: 34, balls: 67 }
    }
  },
  {
    id: 5,
    date: "2024-08-25",
    time: "19:00",
    status: "live",
    format: "T20",
    currentOver: "15.3",
    totalOvers: 20,
    competition: "CPL",
    venue: "Queen's Park Oval",
    stage: "Qualifier",
    currentInnings: 2,
    homeTeam: { name: "Trinidad Knight Riders", code: "TKR", shortName: "Riders" },
    awayTeam: { name: "Barbados Royals", code: "BR", shortName: "Royals" },
    toss: { winner: "Royals", decision: "bowl" },
    score: {
      innings1: { home: { runs: 167, wickets: 7, overs: 20.0 }, away: { runs: 0, wickets: 0, overs: 0 } },
      innings2: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 142, wickets: 5, overs: 15.3 } }
    },
    targetRuns: 168,
    currentBatsmen: {
      striker: { name: "D. Miller", runs: 65, balls: 41 },
      nonStriker: { name: "J. Holder", runs: 18, balls: 14 }
    },
    runRate: { current: 9.28, required: 5.57 }
  },
  {
    id: 6,
    date: "2024-08-25",
    time: "20:00",
    status: "live",
    format: "ODI",
    currentOver: "28.1",
    totalOvers: 50,
    competition: "Asia Cup",
    venue: "Dubai International Stadium",
    stage: "Final",
    currentInnings: 1,
    homeTeam: { name: "India", code: "IND", shortName: "India" },
    awayTeam: { name: "Pakistan", code: "PAK", shortName: "Pakistan" },
    toss: { winner: "India", decision: "bat" },
    score: {
      innings1: { home: { runs: 178, wickets: 3, overs: 28.1 }, away: { runs: 0, wickets: 0, overs: 0 } }
    },
    currentBatsmen: {
      striker: { name: "V. Kohli", runs: 89, balls: 76 },
      nonStriker: { name: "K.L. Rahul", runs: 45, balls: 58 }
    },
    runRate: { current: 6.33, required: null }
  },
  {
    id: 7,
    date: "2024-08-25",
    time: "14:30",
    status: "live",
    format: "T20",
    currentOver: "6.4",
    totalOvers: 20,
    competition: "PSL",
    venue: "National Stadium",
    stage: "Eliminator",
    currentInnings: 1,
    homeTeam: { name: "Karachi Kings", code: "KK", shortName: "Kings" },
    awayTeam: { name: "Lahore Qalandars", code: "LQ", shortName: "Qalandars" },
    toss: { winner: "Kings", decision: "bat" },
    score: {
      innings1: { home: { runs: 48, wickets: 1, overs: 6.4 }, away: { runs: 0, wickets: 0, overs: 0 } }
    },
    currentBatsmen: {
      striker: { name: "B. Azam", runs: 32, balls: 25 },
      nonStriker: { name: "S. Masood", runs: 14, balls: 16 }
    },
    runRate: { current: 7.20, required: null }
  },

  // UPCOMING MATCHES (8)
  {
    id: 20,
    date: "2024-08-26",
    time: "19:30",
    status: "upcoming",
    format: "T20",
    totalOvers: 20,
    competition: "IPL",
    venue: "Eden Gardens",
    stage: "League Stage",
    homeTeam: { name: "Kolkata Knight Riders", code: "KKR", shortName: "Kolkata" },
    awayTeam: { name: "Royal Challengers Bangalore", code: "RCB", shortName: "Bangalore" },
    score: { innings1: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 0, wickets: 0, overs: 0 } } }
  },
  {
    id: 21,
    date: "2024-08-27",
    time: "14:30",
    status: "upcoming",
    format: "ODI",
    totalOvers: 50,
    competition: "World Cup",
    venue: "The Oval",
    stage: "Final",
    homeTeam: { name: "India", code: "IND", shortName: "India" },
    awayTeam: { name: "New Zealand", code: "NZ", shortName: "New Zealand" },
    score: { innings1: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 0, wickets: 0, overs: 0 } } }
  },
  {
    id: 22,
    date: "2024-08-28",
    time: "10:30",
    status: "upcoming",
    format: "Test",
    competition: "Test Championship",
    venue: "Gabba",
    stage: "Final",
    homeTeam: { name: "Australia", code: "AUS", shortName: "Australia" },
    awayTeam: { name: "South Africa", code: "SA", shortName: "South Africa" },
    score: { firstInnings: { australia: { runs: 0, wickets: 0, overs: 0 }, "south africa": { runs: 0, wickets: 0, overs: 0 } } }
  },
  {
    id: 23,
    date: "2024-08-29",
    time: "19:30",
    status: "upcoming",
    format: "T20",
    competition: "BBL",
    venue: "Sydney Cricket Ground",
    stage: "Semi Final",
    homeTeam: { name: "Sydney Thunder", code: "THU", shortName: "Thunder" },
    awayTeam: { name: "Perth Scorchers", code: "SCO", shortName: "Scorchers" },
    score: { innings1: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 0, wickets: 0, overs: 0 } } }
  },
  {
    id: 24,
    date: "2024-08-30",
    time: "15:00",
    status: "upcoming",
    format: "ODI",
    competition: "Champions Trophy",
    venue: "Cardiff",
    stage: "Group Stage",
    homeTeam: { name: "England", code: "ENG", shortName: "England" },
    awayTeam: { name: "West Indies", code: "WI", shortName: "West Indies" },
    score: { innings1: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 0, wickets: 0, overs: 0 } } }
  },
  {
    id: 25,
    date: "2024-08-31",
    time: "10:00",
    status: "upcoming",
    format: "Test",
    competition: "County Championship",
    venue: "Old Trafford",
    stage: "Regular Season",
    homeTeam: { name: "Lancashire", code: "LAN", shortName: "Lancashire" },
    awayTeam: { name: "Yorkshire", code: "YOR", shortName: "Yorkshire" },
    score: { firstInnings: { lancashire: { runs: 0, wickets: 0, overs: 0 }, yorkshire: { runs: 0, wickets: 0, overs: 0 } } }
  },
  {
    id: 26,
    date: "2024-09-01",
    time: "18:00",
    status: "upcoming",
    format: "T20",
    competition: "Vitality Blast",
    venue: "Edgbaston",
    stage: "Final",
    homeTeam: { name: "Birmingham Bears", code: "BIR", shortName: "Bears" },
    awayTeam: { name: "Hampshire Hawks", code: "HAM", shortName: "Hawks" },
    score: { innings1: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 0, wickets: 0, overs: 0 } } }
  },
  {
    id: 27,
    date: "2024-09-02",
    time: "13:30",
    status: "upcoming",
    format: "ODI",
    competition: "List A Cup",
    venue: "Rose Bowl",
    stage: "Semi Final",
    homeTeam: { name: "Hampshire", code: "HAM", shortName: "Hampshire" },
    awayTeam: { name: "Somerset", code: "SOM", shortName: "Somerset" },
    score: { innings1: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 0, wickets: 0, overs: 0 } } }
  },

  // FINISHED MATCHES (25) - Properly structured for each format
  
  // T20 FINISHED MATCHES
  {
    id: 40,
    date: "2024-08-24",
    time: "19:30",
    status: "finished",
    format: "T20",
    competition: "IPL",
    venue: "Chinnaswamy Stadium",
    stage: "Final",
    toss: { winner: "Mumbai", decision: "bowl" },
    homeTeam: { name: "Royal Challengers Bangalore", code: "RCB", shortName: "Bangalore" },
    awayTeam: { name: "Mumbai Indians", code: "MI", shortName: "Mumbai" },
    score: {
      innings1: { home: { runs: 189, wickets: 6, overs: 20.0 }, away: { runs: 0, wickets: 0, overs: 0 } },
      innings2: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 193, wickets: 4, overs: 19.2 } }
    },
    result: "Mumbai won by 6 wickets",
    playerOfTheMatch: "R. Sharma"
  },
  {
    id: 44,
    date: "2024-08-20",
    time: "19:30",
    status: "finished",
    format: "T20",
    competition: "CPL",
    venue: "Queen's Park Oval",
    stage: "Final",
    toss: { winner: "Royals", decision: "bowl" },
    homeTeam: { name: "Trinidad Knight Riders", code: "TKR", shortName: "Riders" },
    awayTeam: { name: "Barbados Royals", code: "BR", shortName: "Royals" },
    score: {
      innings1: { home: { runs: 167, wickets: 7, overs: 20.0 }, away: { runs: 0, wickets: 0, overs: 0 } },
      innings2: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 171, wickets: 4, overs: 18.3 } }
    },
    result: "Royals won by 6 wickets",
    playerOfTheMatch: "D. Miller"
  },
  {
    id: 47,
    date: "2024-08-17",
    time: "20:00",
    status: "finished",
    format: "T20",
    competition: "The Hundred",
    venue: "Lord's",
    stage: "Final",
    toss: { winner: "Originals", decision: "bat" },
    homeTeam: { name: "London Spirit", code: "LSP", shortName: "Spirit" },
    awayTeam: { name: "Manchester Originals", code: "MOR", shortName: "Originals" },
    score: {
      innings1: { home: { runs: 156, wickets: 6, overs: 20.0 }, away: { runs: 0, wickets: 0, overs: 0 } },
      innings2: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 159, wickets: 3, overs: 18.1 } }
    },
    result: "Originals won by 7 wickets",
    playerOfTheMatch: "J. Buttler"
  },
  {
    id: 49,
    date: "2024-08-15",
    time: "18:30",
    status: "finished",
    format: "T20",
    competition: "Vitality Blast",
    venue: "Edgbaston",
    stage: "Semi Final",
    toss: { winner: "Bears", decision: "bowl" },
    homeTeam: { name: "Birmingham Bears", code: "BIR", shortName: "Bears" },
    awayTeam: { name: "Essex Eagles", code: "ESS", shortName: "Eagles" },
    score: {
      innings1: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 142, wickets: 9, overs: 20.0 } },
      innings2: { home: { runs: 146, wickets: 4, overs: 18.2 }, away: { runs: 0, wickets: 0, overs: 0 } }
    },
    result: "Bears won by 6 wickets",
    playerOfTheMatch: "L. Livingstone"
  },
  {
    id: 51,
    date: "2024-08-13",
    time: "19:30",
    status: "finished",
    format: "T20",
    competition: "PSL",
    venue: "National Stadium",
    stage: "Final",
    toss: { winner: "Gladiators", decision: "bat" },
    homeTeam: { name: "Karachi Kings", code: "KK", shortName: "Kings" },
    awayTeam: { name: "Quetta Gladiators", code: "QG", shortName: "Gladiators" },
    score: {
      innings1: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 174, wickets: 6, overs: 20.0 } },
      innings2: { home: { runs: 178, wickets: 3, overs: 19.1 }, away: { runs: 0, wickets: 0, overs: 0 } }
    },
    result: "Kings won by 7 wickets",
    playerOfTheMatch: "S. Ayub"
  },
  {
    id: 54,
    date: "2024-08-10",
    time: "18:00",
    status: "finished",
    format: "T20",
    competition: "BBL",
    venue: "Adelaide Oval",
    stage: "Qualifier",
    toss: { winner: "Strikers", decision: "bowl" },
    homeTeam: { name: "Adelaide Strikers", code: "ADS", shortName: "Strikers" },
    awayTeam: { name: "Melbourne Renegades", code: "REN", shortName: "Renegades" },
    score: {
      innings1: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 153, wickets: 8, overs: 20.0 } },
      innings2: { home: { runs: 157, wickets: 5, overs: 18.4 }, away: { runs: 0, wickets: 0, overs: 0 } }
    },
    result: "Strikers won by 5 wickets",
    playerOfTheMatch: "T. Head"
  },

  // ODI FINISHED MATCHES
  {
    id: 41,
    date: "2024-08-23",
    time: "14:00",
    status: "finished",
    format: "ODI",
    competition: "World Cup",
    venue: "Wankhede Stadium",
    stage: "Semi Final",
    toss: { winner: "India", decision: "bat" },
    homeTeam: { name: "India", code: "IND", shortName: "India" },
    awayTeam: { name: "England", code: "ENG", shortName: "England" },
    score: {
      innings1: { home: { runs: 337, wickets: 7, overs: 50.0 }, away: { runs: 0, wickets: 0, overs: 0 } },
      innings2: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 294, wickets: 10, overs: 48.1 } }
    },
    result: "India won by 43 runs",
    playerOfTheMatch: "V. Kohli"
  },
  {
    id: 45,
    date: "2024-08-19",
    time: "15:00",
    status: "finished",
    format: "ODI",
    competition: "Asia Cup",
    venue: "Dubai International Stadium",
    stage: "Group Stage",
    toss: { winner: "Pakistan", decision: "bowl" },
    homeTeam: { name: "India", code: "IND", shortName: "India" },
    awayTeam: { name: "Pakistan", code: "PAK", shortName: "Pakistan" },
    score: {
      innings1: { home: { runs: 245, wickets: 9, overs: 50.0 }, away: { runs: 0, wickets: 0, overs: 0 } },
      innings2: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 246, wickets: 5, overs: 48.4 } }
    },
    result: "Pakistan won by 5 wickets",
    playerOfTheMatch: "B. Azam"
  },
  {
    id: 48,
    date: "2024-08-16",
    time: "14:30",
    status: "finished",
    format: "ODI",
    competition: "County Championship",
    venue: "Trent Bridge",
    stage: "Group Stage",
    toss: { winner: "Nottinghamshire", decision: "bat" },
    homeTeam: { name: "Nottinghamshire", code: "NOT", shortName: "Notts" },
    awayTeam: { name: "Warwickshire", code: "WAR", shortName: "Warwick" },
    score: {
      innings1: { home: { runs: 278, wickets: 8, overs: 50.0 }, away: { runs: 0, wickets: 0, overs: 0 } },
      innings2: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 232, wickets: 10, overs: 45.2 } }
    },
    result: "Notts won by 46 runs",
    playerOfTheMatch: "S. Mullaney"
  },
  {
    id: 52,
    date: "2024-08-12",
    time: "15:30",
    status: "finished",
    format: "ODI",
    competition: "Tri-Series",
    venue: "Harare Sports Club",
    stage: "Final",
    toss: { winner: "Zimbabwe", decision: "bat" },
    homeTeam: { name: "Zimbabwe", code: "ZIM", shortName: "Zimbabwe" },
    awayTeam: { name: "Ireland", code: "IRE", shortName: "Ireland" },
    score: {
      innings1: { home: { runs: 267, wickets: 7, overs: 50.0 }, away: { runs: 0, wickets: 0, overs: 0 } },
      innings2: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 251, wickets: 9, overs: 50.0 } }
    },
    result: "Zimbabwe won by 16 runs",
    playerOfTheMatch: "S. Williams"
  },
  {
    id: 55,
    date: "2024-08-09",
    time: "13:30",
    status: "finished",
    format: "ODI",
    competition: "Women's World Cup",
    venue: "Bay Oval",
    stage: "Semi Final",
    toss: { winner: "Australia", decision: "bat" },
    homeTeam: { name: "New Zealand Women", code: "NZW", shortName: "NZ Women" },
    awayTeam: { name: "Australia Women", code: "AUSW", shortName: "AUS Women" },
    score: {
      innings1: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 269, wickets: 8, overs: 50.0 } },
      innings2: { home: { runs: 212, wickets: 10, overs: 45.3 }, away: { runs: 0, wickets: 0, overs: 0 } }
    },
    result: "Australia Women won by 57 runs",
    playerOfTheMatch: "E. Perry"
  },
  {
    id: 57,
    date: "2024-08-07",
    time: "14:00",
    status: "finished",
    format: "ODI",
    competition: "Champions Trophy",
    venue: "Cardiff",
    stage: "Group Stage",
    toss: { winner: "England", decision: "bowl" },
    homeTeam: { name: "England", code: "ENG", shortName: "England" },
    awayTeam: { name: "Bangladesh", code: "BAN", shortName: "Bangladesh" },
    score: {
      innings1: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 234, wickets: 9, overs: 50.0 } },
      innings2: { home: { runs: 238, wickets: 3, overs: 42.1 }, away: { runs: 0, wickets: 0, overs: 0 } }
    },
    result: "England won by 7 wickets",
    playerOfTheMatch: "J. Root"
  },

  // TEST MATCHES (CORRECTLY STRUCTURED)
  {
    id: 42,
    date: "2024-08-22",
    time: "10:30",
    status: "finished",
    format: "Test",
    competition: "Ashes",
    venue: "Lord's",
    stage: "5th Test",
    matchDays: 4,
    toss: { winner: "England", decision: "bat" },
    homeTeam: { name: "England", code: "ENG", shortName: "England" },
    awayTeam: { name: "Australia", code: "AUS", shortName: "Australia" },
    score: {
      // England 1st innings (won toss, batted first)
      firstInnings: { england: { runs: 435, wickets: 10, overs: 134.2 }, australia: { runs: 0, wickets: 0, overs: 0 } },
      // Australia 1st innings
      secondInnings: { england: { runs: 0, wickets: 0, overs: 0 }, australia: { runs: 327, wickets: 10, overs: 95.1 } },
      // England 2nd innings
      thirdInnings: { england: { runs: 312, wickets: 10, overs: 89.4 }, australia: { runs: 0, wickets: 0, overs: 0 } },
      // Australia 2nd innings (chasing 421, all out for 285)
      fourthInnings: { england: { runs: 0, wickets: 0, overs: 0 }, australia: { runs: 285, wickets: 10, overs: 78.3 } }
    },
    result: "England won by 135 runs",
    playerOfTheMatch: "J. Root",
    firstInningsLead: 108 // England led by 108 after first innings
  },
  {
    id: 43,
    date: "2024-08-21",
    time: "10:00",
    status: "finished",
    format: "Test",
    competition: "Border-Gavaskar Trophy",
    venue: "MCG",
    stage: "3rd Test",
    matchDays: 5,
    toss: { winner: "Australia", decision: "bat" },
    homeTeam: { name: "Australia", code: "AUS", shortName: "Australia" },
    awayTeam: { name: "India", code: "IND", shortName: "India" },
    score: {
      // Australia 1st innings (won toss, batted first)
      firstInnings: { australia: { runs: 267, wickets: 10, overs: 78.4 }, india: { runs: 0, wickets: 0, overs: 0 } },
      // India 1st innings
      secondInnings: { australia: { runs: 0, wickets: 0, overs: 0 }, india: { runs: 244, wickets: 10, overs: 81.2 } },
      // Australia 2nd innings
      thirdInnings: { australia: { runs: 263, wickets: 10, overs: 89.1 }, india: { runs: 0, wickets: 0, overs: 0 } },
      // India 2nd innings (chasing 287, won by 3 wickets)
      fourthInnings: { australia: { runs: 0, wickets: 0, overs: 0 }, india: { runs: 287, wickets: 7, overs: 98.2 } }
    },
    result: "India won by 3 wickets",
    playerOfTheMatch: "R. Pant",
    firstInningsLead: 23 // Australia led by 23 after first innings
  },
  {
    id: 46,
    date: "2024-08-18",
    time: "10:30",
    status: "finished",
    format: "Test",
    competition: "West Indies Tour",
    venue: "Sabina Park",
    stage: "1st Test",
    matchDays: 3,
    toss: { winner: "West Indies", decision: "bat" },
    homeTeam: { name: "West Indies", code: "WI", shortName: "West Indies" },
    awayTeam: { name: "South Africa", code: "SA", shortName: "South Africa" },
    score: {
      // West Indies 1st innings (won toss, batted first)
      firstInnings: { "west indies": { runs: 212, wickets: 10, overs: 67.2 }, "south africa": { runs: 0, wickets: 0, overs: 0 } },
      // South Africa 1st innings
      secondInnings: { "west indies": { runs: 0, wickets: 0, overs: 0 }, "south africa": { runs: 298, wickets: 10, overs: 89.1 } },
      // West Indies 2nd innings
      thirdInnings: { "west indies": { runs: 145, wickets: 10, overs: 52.3 }, "south africa": { runs: 0, wickets: 0, overs: 0 } },
      // South Africa 2nd innings (chasing 60, won easily)
      fourthInnings: { "west indies": { runs: 0, wickets: 0, overs: 0 }, "south africa": { runs: 62, wickets: 1, overs: 15.4 } }
    },
    result: "South Africa won by 9 wickets",
    playerOfTheMatch: "K. Rabada",
    firstInningsLead: -86 // South Africa led by 86 after first innings
  },
  {
    id: 50,
    date: "2024-08-14",
    time: "11:00",
    status: "finished",
    format: "Test",
    competition: "County Championship",
    venue: "The Oval",
    stage: "Division 1",
    matchDays: 4,
    toss: { winner: "Surrey", decision: "bat" },
    homeTeam: { name: "Surrey", code: "SUR", shortName: "Surrey" },
    awayTeam: { name: "Kent", code: "KEN", shortName: "Kent" },
    score: {
      // Surrey 1st innings (won toss, batted first)
      firstInnings: { surrey: { runs: 387, wickets: 10, overs: 112.3 }, kent: { runs: 0, wickets: 0, overs: 0 } },
      // Kent 1st innings
      secondInnings: { surrey: { runs: 0, wickets: 0, overs: 0 }, kent: { runs: 189, wickets: 10, overs: 58.4 } },
      // Surrey 2nd innings
      thirdInnings: { surrey: { runs: 245, wickets: 8, overs: 67.2 }, kent: { runs: 0, wickets: 0, overs: 0 } },
      // Kent 2nd innings (chasing 443, all out for 178)
      fourthInnings: { surrey: { runs: 0, wickets: 0, overs: 0 }, kent: { runs: 178, wickets: 10, overs: 62.1 } }
    },
    result: "Surrey won by 265 runs",
    playerOfTheMatch: "O. Pope",
    firstInningsLead: 198 // Surrey led by 198 after first innings
  },
  {
    id: 53,
    date: "2024-08-11",
    time: "10:00",
    status: "finished",
    format: "Test",
    competition: "County Championship",
    venue: "Old Trafford",
    stage: "Division 1",
    matchDays: 4,
    toss: { winner: "Lancashire", decision: "bowl" },
    homeTeam: { name: "Lancashire", code: "LAN", shortName: "Lancashire" },
    awayTeam: { name: "Yorkshire", code: "YOR", shortName: "Yorkshire" },
    score: {
      // Yorkshire 1st innings (Lancashire chose to bowl first)
      firstInnings: { lancashire: { runs: 0, wickets: 0, overs: 0 }, yorkshire: { runs: 298, wickets: 10, overs: 89.2 } },
      // Lancashire 1st innings
      secondInnings: { lancashire: { runs: 345, wickets: 10, overs: 98.4 }, yorkshire: { runs: 0, wickets: 0, overs: 0 } },
      // Yorkshire 2nd innings
      thirdInnings: { lancashire: { runs: 0, wickets: 0, overs: 0 }, yorkshire: { runs: 187, wickets: 10, overs: 67.3 } },
      // Lancashire 2nd innings (chasing 141, won by 7 wickets)
      fourthInnings: { lancashire: { runs: 142, wickets: 3, overs: 34.2 }, yorkshire: { runs: 0, wickets: 0, overs: 0 } }
    },
    result: "Lancashire won by 7 wickets",
    playerOfTheMatch: "K. Jennings",
    firstInningsLead: -47 // Lancashire led by 47 after first innings
  },
  {
    id: 59,
    date: "2024-08-05",
    time: "11:00",
    status: "finished",
    format: "Test",
    competition: "Sri Lanka Tour",
    venue: "Galle International Stadium",
    stage: "2nd Test",
    matchDays: 4,
    toss: { winner: "Sri Lanka", decision: "bat" },
    homeTeam: { name: "Sri Lanka", code: "SL", shortName: "Sri Lanka" },
    awayTeam: { name: "New Zealand", code: "NZ", shortName: "New Zealand" },
    score: {
      // Sri Lanka 1st innings (won toss, batted first)
      firstInnings: { "sri lanka": { runs: 315, wickets: 10, overs: 89.2 }, "new zealand": { runs: 0, wickets: 0, overs: 0 } },
      // New Zealand 1st innings
      secondInnings: { "sri lanka": { runs: 0, wickets: 0, overs: 0 }, "new zealand": { runs: 178, wickets: 10, overs: 52.4 } },
      // Sri Lanka 2nd innings
      thirdInnings: { "sri lanka": { runs: 194, wickets: 8, overs: 56.3 }, "new zealand": { runs: 0, wickets: 0, overs: 0 } },
      // New Zealand 2nd innings (chasing 332, won by 1 wicket)
      fourthInnings: { "sri lanka": { runs: 0, wickets: 0, overs: 0 }, "new zealand": { runs: 285, wickets: 9, overs: 89.1 } }
    },
    result: "New Zealand won by 1 wicket",
    playerOfTheMatch: "T. Southee",
    firstInningsLead: 137 // Sri Lanka led by 137 after first innings
  },

  // Additional finished matches to reach 25 total
  {
    id: 56,
    date: "2024-08-08",
    time: "16:00",
    status: "finished",
    format: "T20",
    competition: "WBBL",
    venue: "Junction Oval",
    stage: "Final",
    toss: { winner: "Stars", decision: "bat" },
    homeTeam: { name: "Melbourne Stars Women", code: "MSTW", shortName: "Stars W" },
    awayTeam: { name: "Sydney Thunder Women", code: "STHW", shortName: "Thunder W" },
    score: {
      innings1: { home: { runs: 145, wickets: 7, overs: 20.0 }, away: { runs: 0, wickets: 0, overs: 0 } },
      innings2: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 149, wickets: 4, overs: 18.3 } }
    },
    result: "Thunder Women won by 6 wickets",
    playerOfTheMatch: "P. Litchfield"
  },
  {
    id: 58,
    date: "2024-08-06",
    time: "19:30",
    status: "finished",
    format: "T20",
    competition: "T20 Blast",
    venue: "Headingley",
    stage: "Quarter Final",
    toss: { winner: "Vikings", decision: "bat" },
    homeTeam: { name: "Yorkshire Vikings", code: "YOR", shortName: "Vikings" },
    awayTeam: { name: "Durham Jets", code: "DUR", shortName: "Jets" },
    score: {
      innings1: { home: { runs: 162, wickets: 6, overs: 20.0 }, away: { runs: 0, wickets: 0, overs: 0 } },
      innings2: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 148, wickets: 9, overs: 20.0 } }
    },
    result: "Vikings won by 14 runs",
    playerOfTheMatch: "A. Lyth"
  },
  {
    id: 60,
    date: "2024-08-04",
    time: "17:30",
    status: "finished",
    format: "T20",
    competition: "Caribbean Premier League",
    venue: "Brian Lara Stadium",
    stage: "Eliminator",
    toss: { winner: "Patriots", decision: "bowl" },
    homeTeam: { name: "St Kitts Patriots", code: "SKP", shortName: "Patriots" },
    awayTeam: { name: "Guyana Amazon Warriors", code: "GAW", shortName: "Warriors" },
    score: {
      innings1: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 189, wickets: 4, overs: 20.0 } },
      innings2: { home: { runs: 173, wickets: 8, overs: 20.0 }, away: { runs: 0, wickets: 0, overs: 0 } }
    },
    result: "Warriors won by 16 runs",
    playerOfTheMatch: "S. Hetmyer"
  },
  {
    id: 61,
    date: "2024-08-03",
    time: "15:00",
    status: "finished",
    format: "ODI",
    competition: "Ireland Tour",
    venue: "Malahide",
    stage: "3rd ODI",
    toss: { winner: "Afghanistan", decision: "bat" },
    homeTeam: { name: "Ireland", code: "IRE", shortName: "Ireland" },
    awayTeam: { name: "Afghanistan", code: "AFG", shortName: "Afghanistan" },
    score: {
      innings1: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 289, wickets: 6, overs: 50.0 } },
      innings2: { home: { runs: 256, wickets: 10, overs: 47.2 }, away: { runs: 0, wickets: 0, overs: 0 } }
    },
    result: "Afghanistan won by 33 runs",
    playerOfTheMatch: "R. Gurbaz"
  },
  {
    id: 62,
    date: "2024-08-02",
    time: "20:00",
    status: "finished",
    format: "T20",
    competition: "Global T20 Canada",
    venue: "CAA Centre",
    stage: "Final",
    toss: { winner: "Tigers", decision: "bat" },
    homeTeam: { name: "Montreal Tigers", code: "MT", shortName: "Tigers" },
    awayTeam: { name: "Toronto Nationals", code: "TN", shortName: "Nationals" },
    score: {
      innings1: { home: { runs: 158, wickets: 7, overs: 20.0 }, away: { runs: 0, wickets: 0, overs: 0 } },
      innings2: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 162, wickets: 3, overs: 18.4 } }
    },
    result: "Nationals won by 7 wickets",
    playerOfTheMatch: "C. Munro"
  },
  {
    id: 63,
    date: "2024-08-01",
    time: "12:30",
    status: "finished",
    format: "ODI",
    competition: "Netherlands Tour",
    venue: "VRA Ground",
    stage: "2nd ODI",
    toss: { winner: "Netherlands", decision: "bowl" },
    homeTeam: { name: "Netherlands", code: "NED", shortName: "Netherlands" },
    awayTeam: { name: "Scotland", code: "SCO", shortName: "Scotland" },
    score: {
      innings1: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 198, wickets: 10, overs: 42.3 } },
      innings2: { home: { runs: 202, wickets: 4, overs: 38.2 }, away: { runs: 0, wickets: 0, overs: 0 } }
    },
    result: "Netherlands won by 6 wickets",
    playerOfTheMatch: "M. O'Dowd"
  },
  {
    id: 64,
    date: "2024-07-31",
    time: "18:30",
    status: "finished",
    format: "T20",
    competition: "Euro T20 Slam",
    venue: "Malahide",
    stage: "Group Stage",
    toss: { winner: "Knights", decision: "bat" },
    homeTeam: { name: "Dublin Chiefs", code: "DC", shortName: "Chiefs" },
    awayTeam: { name: "Belfast Knights", code: "BK", shortName: "Knights" },
    score: {
      innings1: { home: { runs: 0, wickets: 0, overs: 0 }, away: { runs: 167, wickets: 6, overs: 20.0 } },
      innings2: { home: { runs: 171, wickets: 5, overs: 19.2 }, away: { runs: 0, wickets: 0, overs: 0 } }
    },
    result: "Chiefs won by 5 wickets",
    playerOfTheMatch: "P. Stirling"
  }
];
